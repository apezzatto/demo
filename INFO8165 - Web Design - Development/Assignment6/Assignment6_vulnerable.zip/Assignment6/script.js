function setCookie(){
	document.cookie = "sessionID=314159";
//alert(document.cookie);
}

function ChangeText(){
  var inputVar = document.getElementById("userName").value;
	document.write("<h1>Hello " + inputVar + "!</h1>" + "<p id=\"welcomeParagraph2\">Please enjoy the website!</p>");
	// alert(inputVar);
}

function stopRKey(evt){
	var node = (evt.target) ?  evt.target :((evt.srcElement) ?  evt.srcElement :  null);
	var evt = (evt) ?  evt :  ((event) ?  event :  null);
	if ((evt.keyCode == 13) && (node.type == "text"))
	{
		return false;
	}
}
document.onkeypress = stopRKey;
